package com.example.oelbyamna;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ChildDashboard extends AppCompatActivity {
Button btn2,btn3;
TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child_dashboard);
        btn2=(Button) findViewById(R.id.btn2);
        btn3=(Button) findViewById(R.id.btn3);
        txt=(TextView) findViewById(R.id.txtlogout);
    }

    public void onbtn2Click(View v){
        Intent i=new Intent(this,ChildActivity2.class);
        startActivity(i);
    }public void onbtn3Click(View v){
        Intent i=new Intent(this,ChildActivity3.class);
        startActivity(i);
    }
    public void gotoLogin(View v){
        finish();
        Intent i=new Intent(this,LoginActivity.class);
        startActivity(i);
    }
}
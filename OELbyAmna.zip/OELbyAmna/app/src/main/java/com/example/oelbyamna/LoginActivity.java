package com.example.oelbyamna;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
Button btnlogin;
EditText username,password;
    int clickcount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btnlogin=(Button) findViewById(R.id.btnlogin);
        username=(EditText) findViewById(R.id.edtusername);
        password=(EditText) findViewById(R.id.edtpass);
        clickcount=0;
    }
    public void onClick(View v) {
        clickcount = clickcount+1;
        if(clickcount<3)
        {
            if (username.getText().toString().equals("child") && password.getText().toString().equals("12345")) {
                username.setText("");
                password.setText("");
                Intent i=new Intent(this,ChildDashboard.class);
                startActivity(i);
            } else if (username.getText().toString().equals("") || password.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Fill the above fields", Toast.LENGTH_SHORT).show();
                clickcount=0;
            } else {
                Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        }
        else if(clickcount==3){
            if (username.getText().toString().equals("parent") && password.getText().toString().equals("23456")) {
                clickcount=0;
                Intent i=new Intent(this,ParentDashboard.class);
                startActivity(i);
            } else if (username.getText().toString().equals("") || password.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Fill the above fields", Toast.LENGTH_SHORT).show();
                clickcount=0;
            } else {
                Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                clickcount=0;
            }
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Fill the above fields", Toast.LENGTH_SHORT).show();
            clickcount=0;
        }
    }
}
package com.example.oelbyamna;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ParentDashboard extends AppCompatActivity {
Button btnreport, btnLock;
    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_dashboard);
        btnreport=(Button) findViewById(R.id.btnreport);
        btnLock=(Button) findViewById(R.id.btnLock);
        txt=(TextView) findViewById(R.id.txtlogout);
    }
    public void onBtnReport(View v){
        Intent i=new Intent(this,ChildrenReports.class);
        startActivity(i);
    }
    public void onBtnLock(View v){
        Toast.makeText(getApplicationContext(),"Child Phone Locked", Toast.LENGTH_SHORT).show();
    }
    public void gotoLogin(View v){
        Intent i=new Intent(this,LoginActivity.class);
        startActivity(i);
    }
}